import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;

public class Main {
//Tenemos la clase tarea con todos sus atributos
    static class Tarea {
        private String nombre;
        private int prioridad;
        private boolean completada;
        private String nota;

        public Tarea(String nombre, int prioridad, String nota) {
            this.nombre = nombre;
            this.prioridad = prioridad;
            this.completada = false;
            this.nota = nota;
        }
//Algunos getters para que retornen
        public String getNombre() { return nombre; }
        public int getPrioridad() {
            return prioridad;
        }
        public String getNota() { return nota; }

        public void marcarCompletada() { this.completada = true; }

        public String getEstado() {
            return completada ? "Completada" : "Pendiente";
        }

        @Override
        public String toString() {
            return nombre;
        }
//Aqui tenemos las prioridades en las cuales se elegiran dependiendo de la prioridad
        public String toArchivo() {
            String prioridad1 = switch (prioridad) {
                case 1 -> "Alta";
                case 2 -> "Media";
                default -> "Baja";
            };
//Aqui esta el como se guardara en el txt, primero el nombre, la prioridad, un operador ternario para elegir si esta completada o no
            return nombre + "|" + prioridad1 + "|" + (completada ? "Completada" : "Pendiente") + "|" + nota.replace("\n", "\\n");
        }

//Aqui tenemos la clase Tarea en la cual se esta sacando todos los atributos y se asignan para que cuando guardes
    //el archivo, aparezca lo elegido
        public static Tarea desdeArchivo(String linea) {
            try {
                String[] partes = linea.split("\\|", 4);
                String nombre = partes[0].trim();
                String prioridad1 = partes[1].trim();
                String estado = partes[2].trim();

                String nota = partes.length > 3 ? partes[3].replace("\\n", "\n") : "";
                int prioridad;
                switch (prioridad1.toLowerCase()) {
                    case "alta" -> prioridad = 1;
                    case "media" -> prioridad = 2;
                    default -> prioridad = 3; // baja
                }
                Tarea t = new Tarea(nombre, prioridad, nota);

                if (estado.equalsIgnoreCase("Completada")) {
                    t.marcarCompletada();
                }
                return t;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al cargar una tarea: " + linea);
                return new Tarea("Tarea desconocida", 3, "");
            }
        }
    }

    private static final ArrayList<Tarea> tareas = new ArrayList<>();
    private static JList<Tarea> listaTareas;

//Aqui ya esta el main en donde se ponen los estilos, el ancho, altura y demas de los paneles
    public static void main(String[] args) {
        JFrame ventana = new JFrame("Gestor de Tareas");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(700, 500);
        ventana.setLayout(new BorderLayout());

        listaTareas = new JList<>();
        listaTareas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        listaTareas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 1) {
                    Tarea seleccionada = listaTareas.getSelectedValue();
                    if (seleccionada != null) {
                        JOptionPane.showMessageDialog(null,
                                "Nota de la tarea:\n" + seleccionada.getNota(),
                                seleccionada.getNombre(),
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });

        listaTareas.setCellRenderer((list, value, index, isSelected, cellHasFocus) -> {
            Tarea tarea = (Tarea) value;

            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createEmptyBorder(5, 5, 5, 5),
                    BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1)
            ));
            panel.setBackground(isSelected ? new Color(220, 235, 255) : Color.WHITE);

            JLabel lblNombre = new JLabel(tarea.getNombre());
            lblNombre.setFont(new Font("Segoe UI", Font.BOLD, 16));

            JLabel lblPrioridad = new JLabel();
            lblPrioridad.setFont(new Font("Segoe UI", Font.PLAIN, 14));

//Aqui dependiendo de lo que eligas tendra su propio label con su texto, color y demas
            switch (tarea.getPrioridad()) {
                case 1 -> {
                    lblPrioridad.setText("Alta");
                    lblPrioridad.setForeground(Color.RED);
                }
                case 2 -> {
                    lblPrioridad.setText("Media");
                    lblPrioridad.setForeground(new Color(255, 165, 0));
                }
                case 3 -> {
                    lblPrioridad.setText("Baja");
                    lblPrioridad.setForeground(new Color(0, 128, 0));
                }
            }

            JLabel lblEstado = new JLabel(tarea.getEstado());
            lblEstado.setFont(new Font("Segoe UI", Font.ITALIC, 13));
            lblEstado.setForeground(tarea.getEstado().equals("Completada") ? new Color(0, 150, 0) : new Color(180, 0, 0));

            JPanel top = new JPanel(new BorderLayout());
            top.setOpaque(false);
            top.add(lblNombre, BorderLayout.WEST);
            top.add(lblPrioridad, BorderLayout.EAST);

            panel.add(top, BorderLayout.NORTH);
            panel.add(lblEstado, BorderLayout.SOUTH);

            return panel;
        });

        JScrollPane scroll = new JScrollPane(listaTareas);
        ventana.add(scroll, BorderLayout.CENTER);

//Asignamos botones y que haran cada uno de ellos
        JPanel panelBotones = new JPanel();
        panelBotones.setBackground(new Color(230, 240, 250));

        JButton btnAgregar = new JButton("Agregar tarea");
        JButton btnCompletar = new JButton("Marcar como completada");
        JButton btnEliminar = new JButton("Eliminar tarea");
        JButton btnGuardar = new JButton("Guardar");
        JButton btnCargar = new JButton("Cargar");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnCompletar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnGuardar);
        panelBotones.add(btnCargar);

        ventana.add(panelBotones, BorderLayout.SOUTH);

        btnAgregar.addActionListener(e -> agregarTarea());
        btnCompletar.addActionListener(e -> marcarCompletada());
        btnEliminar.addActionListener(e -> eliminarTarea());
        btnGuardar.addActionListener(e -> guardarTareas());
        btnCargar.addActionListener(e -> cargarTareas());

        ventana.setVisible(true);
    }
//Tenemos la funcion de agregar las tareas, en la cual se elige el nombre, las opciones de la prioridad y notas
    private static void agregarTarea() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.add(new JLabel("Nombre de la tarea:"));
        JTextField txtNombre = new JTextField();
        panel.add(txtNombre);

        panel.add(new JLabel("Prioridad:"));
        String[] opciones = {"Alta", "Media", "Baja"};
        JComboBox<String> cbPrioridad = new JComboBox<>(opciones);
        panel.add(cbPrioridad);

        panel.add(new JLabel("Nota:"));
        JTextArea txtNota = new JTextArea(3, 20);
        JScrollPane notaScroll = new JScrollPane(txtNota);
        panel.add(notaScroll);

        int result = JOptionPane.showConfirmDialog(null, panel, "Nueva tarea", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String nombre = txtNombre.getText().trim();
            if (nombre.isEmpty()) return;

            int prioridad = cbPrioridad.getSelectedIndex() + 1;
            String nota = txtNota.getText().trim();

            tareas.add(new Tarea(nombre, prioridad, nota));
            actualizarLista();
        }
    }
//Aqui tenemos el marcar la tarea como completada, en la cual si la marcamos como completada la lista se actualiza
    private static void marcarCompletada() {
        Tarea seleccionada = listaTareas.getSelectedValue();
        if (seleccionada != null) {
            seleccionada.marcarCompletada();
            actualizarLista();
        } else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una tarea.");
        }
    }
//Aqui esta el eliminar tarea en la cual la elimina y actualiza la lista
    private static void eliminarTarea() {
        if (tareas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay tareas para eliminar.");
            return;
        }

        JComboBox<Tarea> combo = new JComboBox<>(tareas.toArray(new Tarea[0]));
        int result = JOptionPane.showConfirmDialog(null, combo, "Selecciona la tarea a eliminar", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            tareas.remove(combo.getSelectedItem());
            actualizarLista();
        }
    }
//Esta es la parte de actualizar lista en la cual tenemos una lista de todas las que tenemos
    private static void actualizarLista() {
        tareas.sort(Comparator.comparingInt(Tarea::getPrioridad));
        listaTareas.setListData(tareas.toArray(new Tarea[0]));
    }
//Esta es el apartado de guardar tareas, en donde todo lo que tengamos anterior lo guarda en un txt
    private static void guardarTareas() {
        try (PrintWriter writer = new PrintWriter("tareas.txt")) {
            for (Tarea t : tareas) writer.println(t.toArchivo());
            JOptionPane.showMessageDialog(null, "Las tareas se han guardado en el archivo tareas.txt");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar el archivo.");
        }
    }
//El apartado de cargar tareas saca todo lo guardado desde el txt y se arroja al panel principal
    private static void cargarTareas() {
        tareas.clear();
        File archivo = new File("tareas.txt");
        if (!archivo.exists()) {
            JOptionPane.showMessageDialog(null, "No se encontró el archivo tareas.txt");
            return;
        }

        try (Scanner scanner = new Scanner(archivo)) {
            while (scanner.hasNextLine()) tareas.add(Tarea.desdeArchivo(scanner.nextLine()));
            actualizarLista();
            JOptionPane.showMessageDialog(null, "Las tareas se han cargado correctamente.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al leer el archivo.");
        }
    }
}
